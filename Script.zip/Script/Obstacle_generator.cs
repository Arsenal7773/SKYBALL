using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle_generator : MonoBehaviour
{
    public GameObject obstacle;
    public GameObject finish;
    public float offset=30f;
    public float SpawnTime = 2f;
    public float timer=3f;
    
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if(timer >= SpawnTime)
        {
            Spawn_Obstacle();
            timer = 0;
        }   
    }
    public void Spawn_Obstacle()
    {
        Instantiate(obstacle,new Vector3(Random.Range(transform.position.x - offset,transform.position.x + offset),transform.position.y,transform.position.z),transform.rotation);
    }
    public void Spawn_finish()
    {
        Instantiate(finish,transform.position,transform.rotation);
    }
}








