using UnityEngine;

public class Obstacle_move : MonoBehaviour
{
    public float movespeed=10f;
    public float deadzone = -2f;

    // Update is called once per frame
    void Update()
    {
        transform.position -= (Vector3.forward*movespeed)*Time.deltaTime;
        if(transform.position.z < deadzone)
        {
            Destroy(gameObject);
        }
    }
}
