using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class game_over_menu : MonoBehaviour
{
    public AudioSource sfx;
    public AudioClip sfx1;

    public void mainMenu()
    {
        sfx.clip = sfx1;
        sfx.Play();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex-1);
    } 
    
    public void Quit()
    {
        sfx.clip = sfx1;
        sfx.Play();

       Debug.Log("Quit");
       Application.Quit();
    }
    public void Restart()
    {
        sfx.clip = sfx1;
        sfx.Play();

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
