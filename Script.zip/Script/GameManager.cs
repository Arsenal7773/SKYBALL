using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour
{
    public bool IsGameEnded = false;
    public GameObject GameOverUI;
    public Obstacle_generator obsGen;
    public Text score,Hi_Score;
    public int playerScore,highScore=0;
    public float time;
    private float T;
    public AudioSource SFX,SFX2;
    public AudioClip sfx1, sfx2, sfx3;
    public GameObject gamePanel;

    void Start()
    {
       LoadHighScore(); 
        score.text ="Score : " + playerScore.ToString();
        Hi_Score.text = "High Score : " + highScore.ToString();
   
      
    }
    public void EndGame()
    {
        if(!IsGameEnded)
        {
            IsGameEnded=true;
            Debug.Log("Game Over");
            GameOverUI.SetActive(true);
        }
    }
    [ContextMenu("Increase score")]
    public void addScore(int scoreToAdd)
    {
        if(!IsGameEnded)
        {
           playerScore += 1;
           SaveHighScore(playerScore);
           LoadHighScore();
           score.text ="Score : " + playerScore.ToString();
           Hi_Score.text = "High Score : " + highScore.ToString();
           SFX.clip = sfx1;
           SFX.Play();
        }
    }
    void Update()
    {   
        T+=Time.deltaTime;
        if(T>=1 && !IsGameEnded)
        {
            time++;
            T=0;
        }
    }public void SaveHighScore(int playerScore)
    {
        if(playerScore > highScore)
        {
            highScore = playerScore;
            PlayerPrefs.SetInt("HighScore",highScore);
            PlayerPrefs.Save();
        }
    }
    public int GetHighScore()
    {
        return highScore;
    }

    private void LoadHighScore()
    {
        highScore = PlayerPrefs.GetInt("HighScore", 0);
    }
    


}
