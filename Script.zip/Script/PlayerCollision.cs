using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public PlayerMovement movement;
    //OnCollisionEnter detect collision 
    void OnCollisionEnter (Collision collisionInfo)//Collision gather info. about the obstacle
    {
        Debug.Log(collisionInfo.collider.name);//give any info. about collider. eg: name. 
        if(collisionInfo.collider.tag == "Obstacle")
        {
            movement.enabled = false;
            FindObjectOfType<GameManager>().EndGame();
        }
    }
}
