﻿using UnityEngine;
using UnityEngine.SceneManagement;
public class MENU : MonoBehaviour
{
    public GameObject CraditsPanel;
    public GameObject MainMenuPanal;
    public void Cradits()
    {
        MainMenuPanal.SetActive(false);
        CraditsPanel.SetActive(true);
    }
    public void StartGame ()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    } 
    
    public void Quit ()
    {
       Debug.Log("Quit");
       Application.Quit();
    }
    public void Back()
    {
        MainMenuPanal.SetActive(true);
        CraditsPanel.SetActive(false);
    }
    
    
}
