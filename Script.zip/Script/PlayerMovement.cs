using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Rigidbody rb;
    public float forwardforce = 200f;
    public float sidewaysforce = 5f;
    public AudioSource sfx;
    public AudioClip B_clip;
    // Start is called before the first frame update
    void Start()
    {
        sfx.clip = B_clip;
        Debug.Log("Hello world!");
        sfx.Play();
    }

    // Update is called once per frame
    // FixedUpdate is use when we do physics stuff like Adding force,changing velocity etc.
    //it makes smoother
    void FixedUpdate()
    {
        //add a forward force
        rb.AddForce(0 , 0, forwardforce * Time.deltaTime);
        //Time.deltaTime is a Unity specific variable that represents the time interval in seconds it took from last frame to the current frame.//
        
        if( Input.GetKey("d") )
        {
            rb.AddForce(sidewaysforce * Time.deltaTime ,0 ,0 ,ForceMode.VelocityChange);
        }
        if( Input.GetKey("a") )
        {
            rb.AddForce(-sidewaysforce * Time.deltaTime ,0 ,0 ,ForceMode.VelocityChange);
        }
        if(rb.position.y <1.210819)
        {
            FindObjectOfType<GameManager>().EndGame();
        }
        
    }
}
